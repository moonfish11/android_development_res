package com.youngheart.activity.news;

import com.youngheart.R;

import android.app.Activity;
import android.os.Bundle;

public class NewsActivity extends Activity {	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);	
		
		setContentView(R.layout.activity_news);
	}
}
