package com.infrastructure.utils;

public class FrameConstants {
	public static final String ACCEPT_CHARSET = "Accept-Charset";
	public static final String USER_AGENT = "User-Agent";
	public static final String ACCEPT_ENCODING = "Accept-Encoding";
}
