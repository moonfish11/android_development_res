package com.example.youngheart;

import android.app.Activity;
import android.os.Bundle;

public class PersonCenterActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
}
